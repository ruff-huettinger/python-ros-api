import math, time, threading
from ros_api.lib_robot import Robot, CollistionTyp



class PledgeAlgo(threading.Thread):
    LEFTHAND = "left"
    RIGHTHAND = "right"

    NOTHING = -1
    MOVE_TO_WALL_STEP = 0
    TURN_LEFT_STEP = 1
    TURN_RIGHT_STEP = 2
    FOLLOW_WALL_STEP = 3


    def __init__(self,robot:Robot, leftRightHandMode:str="left") -> None:
        super().__init__()
        self.robot = robot
        self.leftRightMode = leftRightHandMode.lower()
        self.running = False
        self.rotationCounter = 0
        self.lastRotationCountValue = 0
        self.runningToNextWall = False
        self.runningFollowWall = False
        self.turningOnceBlocker = False
        self.currentStep = PledgeAlgo.NOTHING
        self.minDistanceToWall = None
        self.leftRightDifference = 0.05 #+-5cm

    def degToRadConverter(self, deg) -> float:
        return float(deg) * (math.pi / 180.0)

    def rotationCount(self, direction):
        self.turningOnceBlocker = True
        self.lastRotationCountValue = self.rotationCount
        if (self.leftRightMode == PledgeAlgo.LEFTHAND):
            if (direction == PledgeAlgo.LEFTHAND):
                self.rotationCounter += 1
            else:
                self.rotationCounter -= 1
        else:
            if (direction == PledgeAlgo.RIGHTHAND):
                self.rotationCounter += 1
            else:
                self.rotationCounter -= 1

    def checkRotationToZerro(self) -> bool:
        return (self.rotationCounter == 0 and self.rotationCounter != 0)
    
    def checkQRCode(self):
        if(self.robot.qrCode == 'goalPose' or self.robot.qrCode != ''):
            print('Robot is on the GOAL Position *** Stoping')
            self.stop()

    def robotCallback(self, msg):
        if(msg == 'finish'):
            if(self.currentStep == PledgeAlgo.TURN_LEFT_STEP or self.currentStep == PledgeAlgo.TURN_RIGHT_STEP):
                print("PLEDGE-ALGO FINISCH TURN",self.currentStep, self.robot.checkRobotLeftRightUnavailable())
                if(self.leftRightMode == PledgeAlgo.LEFTHAND):
                    self.minDistanceToWall = self.robot.ultrasonicRightValue.range
                else:
                    self.minDistanceToWall = self.robot.ultrasonicLeftValue.range
                self.currentStep = self.getNextStep()
                print(self.currentStep)

    def moveToNextWall(self):
        self.runningToNextWall = True
        collidedToFrontWall = CollistionTyp.NOTHING
        self.robot.moveRobot(0.05, 0.0, 0.0)
        while (self.runningToNextWall and not (collidedToFrontWall == CollistionTyp.LIDAR_FRONT)):
            collidedToFrontWall = self.robot.checkCollision()
            self.checkQRCode()
            # print(collidedToFrontWall)
            if(collidedToFrontWall == CollistionTyp.LIDAR_FRONT):
                self.runningToNextWall = False
                break
            time.sleep(0.001)
        self.robot.moveRobot(0.0, 0.0, 0.0)
        self.currentStep = self.getNextStep()

    def turnLeft(self):
        print("turnLeft")
        turnValue = self.degToRadConverter(70)
        self.rotationCount(PledgeAlgo.LEFTHAND)
        # self.robot.moveTurnStep(1, 1, turnValue, self.robotCallback)
        self.robot.moveTurnStepRad(1, 1, turnValue, self.robotCallback)
        # self.robot.runTurning(self.degToRadConverter(70-10), None)
        print("After turnLeft")
        # self.currentStep = self.getNextStep()

    def turnRight(self):
        print("turnRight")
        turnValue = self.degToRadConverter(-70)
        self.rotationCount(PledgeAlgo.RIGHTHAND)
        # self.robot.moveTurnStep(1, 1, turnValue, self.robotCallback)
        self.robot.moveTurnStepRad(1, 1, turnValue, self.robotCallback)
        # self.robot.runTurning(self.degToRadConverter(-70+10), None)
        print("After turnRight")
        # self.currentStep = self.getNextStep()

    def getNextStep(self):
        nextStep = PledgeAlgo.NOTHING
        self.checkQRCode()
        if(self.checkRotationToZerro()):
            print("rotation Zerro")
            nextStep = PledgeAlgo.MOVE_TO_WALL_STEP
        elif(self.currentStep == PledgeAlgo.MOVE_TO_WALL_STEP):
            if(self.leftRightMode == PledgeAlgo.LEFTHAND):
                print("after move to wall turn right")
                nextStep = PledgeAlgo.TURN_RIGHT_STEP
            else:
                print("after move to wall turn left")
                nextStep = PledgeAlgo.TURN_LEFT_STEP
        elif(self.currentStep == PledgeAlgo.TURN_LEFT_STEP or self.currentStep == PledgeAlgo.TURN_RIGHT_STEP):
            print("after turn")
            # self.turningOnceBlocker = False
            nextStep = PledgeAlgo.FOLLOW_WALL_STEP
        elif(self.currentStep == PledgeAlgo.FOLLOW_WALL_STEP):
            if(self.robot.checkCollision() == CollistionTyp.LIDAR_FRONT):
                # if(self.robot.checkRobotLeftRightUnavailable() == CollistionTyp.LIDAR_LEFT):
                if(abs(self.minDistanceToWall - self.robot.ultrasonicLeftValue.range) < self.leftRightDifference*2):
                    print("follow wall step front collistion and left is collistion")
                    nextStep = PledgeAlgo.TURN_RIGHT_STEP
                # elif(self.robot.checkRobotLeftRightUnavailable() == CollistionTyp.LIDAR_RIGHT):
                elif(abs(self.minDistanceToWall - self.robot.ultrasonicRightValue.range) < self.leftRightDifference*2):
                    print("follow wall step front collistion and right is collistion")
                    nextStep = PledgeAlgo.TURN_LEFT_STEP
            elif(self.leftRightMode == PledgeAlgo.LEFTHAND):
                # if(abs(self.minDistanceToWall - self.robot.ultrasonicLeftValue.range) < self.leftRightDifference*2):
                # if(self.robot.checkRobotLeftRightUnavailable() != CollistionTyp.LIDAR_LEFT and self.robot.checkRobotLeftRightUnavailable() != CollistionTyp.LIDAR_LEFT_RIGHT):
                nextStep = PledgeAlgo.TURN_LEFT_STEP
            elif(self.leftRightMode == PledgeAlgo.RIGHTHAND):
                # if(abs(self.minDistanceToWall - self.robot.ultrasonicRightValue.range) < self.leftRightDifference*2):
                # if(self.robot.checkRobotLeftRightUnavailable() != CollistionTyp.LIDAR_RIGHT and self.robot.checkRobotLeftRightUnavailable() != CollistionTyp.LIDAR_LEFT_RIGHT):
                nextStep = PledgeAlgo.TURN_RIGHT_STEP
        print("rightFull", self.minDistanceToWall,  '-', self.robot.ultrasonicRightValue.range)
        print("leftFull", self.minDistanceToWall, "-" ,self.robot.ultrasonicLeftValue.range)
        print("getNextStep:", nextStep)
        return nextStep 

    def followWall(self):
        print("followWall")
        time.sleep(2)
        self.turningOnceBlocker = False
        self.runningFollowWall = True
        collidedToFrontWall = self.robot.checkCollision()
        followedWall = CollistionTyp.NOTHING
        if(self.leftRightMode == PledgeAlgo.LEFTHAND):
            self.minDistanceToWall = self.robot.ultrasonicLeftValue.range
        else:
            self.minDistanceToWall = self.robot.ultrasonicRightValue.range
        self.robot.moveRobot(0.05, 0.0, 0.0)
        while (self.runningFollowWall and not (collidedToFrontWall == CollistionTyp.LIDAR_FRONT)):
            collidedToFrontWall = self.robot.checkCollision()
            followedWall = self.robot.checkRobotLeftRightUnavailable()
            self.checkQRCode()
            print("followWall", collidedToFrontWall, "Ulra", self.minDistanceToWall, self.robot.ultrasonicLeftValue.range, self.robot.ultrasonicRightValue.range)
            # print("followWall*********************"*", followedWall, collidedToFrontWall)
            if(collidedToFrontWall == CollistionTyp.LIDAR_FRONT):
                self.runningFollowWall = False
                break
            # if(followedWall != -1):
            # if(self.leftRightMode == PledgeAlgo.LEFTHAND and (followedWall != CollistionTyp.LIDAR_LEFT and followedWall != CollistionTyp.LIDAR_LEFT_RIGHT)):
            if(self.leftRightMode == PledgeAlgo.LEFTHAND):
                if(self.robot.ultrasonicLeftValue.range > (self.minDistanceToWall + self.leftRightDifference*2)):
                    print("+++++++++ break")
                    self.runningFollowWall = False
                    break
                # if(self.robot.ultrasonicLeftValue.range < (self.minDistanceToWall - self.leftRightDifference)):
                #     self.robot.runTurning(self.degToRadConverter(10), None)
                #     self.robot.moveRobot(0.05, 0.0, 0.0)
                # if(self.robot.ultrasonicLeftValue.range > (self.minDistanceToWall + self.leftRightDifference)):
                #     self.robot.runTurning(self.degToRadConverter(-10), None)
                #     self.robot.moveRobot(0.05, 0.0, 0.0)
            # elif(self.leftRightMode == PledgeAlgo.RIGHTHAND and (followedWall != CollistionTyp.LIDAR_RIGHT and followedWall != CollistionTyp.LIDAR_LEFT_RIGHT)):
            elif(self.leftRightMode == PledgeAlgo.RIGHTHAND):
                print(self.robot.ultrasonicRightValue.range, "min: ", (self.minDistanceToWall + self.leftRightDifference))
                if(self.robot.ultrasonicRightValue.range > (self.minDistanceToWall + self.leftRightDifference*2)):
                    #counter += 1
                    #if counter > 3:
                    print("---------- break")
                    self.runningFollowWall = False
                    break
                # if(self.robot.ultrasonicRightValue.range < (self.minDistanceToWall - self.leftRightDifference)):
                #     self.robot.runTurning(self.degToRadConverter(10), None)
                #     self.robot.moveRobot(0.05, 0.0, 0.0)
                # if(self.robot.ultrasonicRightValue.range > (self.minDistanceToWall + self.leftRightDifference)):
                #     self.robot.runTurning(self.degToRadConverter(-10), None)
                #     self.robot.moveRobot(0.05, 0.0, 0.0)
            time.sleep(1/25.0)
        self.robot.moveRobot(0.0, 0.0, 0.0)
        self.currentStep = self.getNextStep()
        print('after FollowWall', self.currentStep)

    def stop(self):
        self.running = False
        self.runningFollowWall = False
        self.runningToNextWall = False
        self.turningOnceBlocker = False
        self.rotationCount = 0
        self.currentStep = PledgeAlgo.NOTHING
        self.join()

    def run(self):
        self.running = True
        self.currentStep = PledgeAlgo.MOVE_TO_WALL_STEP
        while self.running:
            self.checkQRCode()
            # print(self.currentStep, self.robot.checkRobotLeftRightUnavailable())
            if(self.currentStep == PledgeAlgo.MOVE_TO_WALL_STEP):
                self.moveToNextWall()
            elif(self.currentStep == PledgeAlgo.TURN_LEFT_STEP):
                if(not self.turningOnceBlocker):
                    self.turnLeft()
            elif(self.currentStep == PledgeAlgo.TURN_RIGHT_STEP):
                if(not self.turningOnceBlocker):
                    self.turnRight()
            elif(self.currentStep == PledgeAlgo.FOLLOW_WALL_STEP):
                self.followWall()
            else:
                self.robot.moveRobot(0.0, 0.0, 0.0)
            
    '''
    TODO:
    Start vom Algo: 
        - rotaionsCounter auf 0
    
    Alogo:
        1. Fahre bis zur nächsten Wand
        2. drehe dich je nach Modus links/rechts
        3. rotationsCounter ein schritt erhöhen/herbasetzten
        4. Die wand folgen und Couter weiter zählen bei jeden drehung: bis rotaionscounter 0 wird oder am ziel angekommen 
            a. am ziel angekommen -> Algo beenden
            b. wen rotaion = 0 fange bei Schritt 1 an 
    '''
