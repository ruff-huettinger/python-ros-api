import os
import threading
import math
import time
from typing import Callable
import numpy as np
from numpy.lib.function_base import angle

import rospy
from std_msgs.msg import Empty, String
from sensor_msgs.msg import Imu, LaserScan, Range
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from kobuki_msgs.msg import MotorPower, PowerSystemEvent, BumperEvent
from tf.transformations import euler_from_quaternion


class CollistionTyp():
    NOTHING = -1
    BUMPER_CENTER = 0
    BUMPER_LEFT = 1
    BUMPER_RIGHT = 2
    LIDAR_FRONT = 3
    LIDAR_BACK = 4
    LIDAR_LEFT = 5
    LIDAR_RIGHT = 6
    LIDAR_LEFT_RIGHT = 7

class SensorObjekt():
    FRONT_LEFT = None
    FRONT_RIGHT = None
    FRONT_CENTER = None
    BACK_LEFT = None
    BACK_RIGHT = None
    BACK_CENTER = None

    def __init__(self, frontLeft=None, frontRight=None, frontCenter=None, backLeft=None, backRight=None, backCenter=None):
        self.FRONT_LEFT = frontLeft
        self.FRONT_RIGHT = frontRight
        self.FRONT_CENTER = frontCenter
        self.BACK_LEFT = backLeft
        self.BACK_RIGHT = backRight
        self.BACK_CENTER = backCenter
        self.data = [self.FRONT_LEFT, self.FRONT_RIGHT, self.FRONT_CENTER, self.BACK_LEFT, self.BACK_RIGHT, self.BACK_CENTER]
        self.__length = 6



class Robot(threading.Thread):
    def __init__(self, rateValue:int=25):
        super().__init__()

        self.rateValue = rateValue
        rospy.init_node("Lib_ROBOT")
        self.rate = rospy.Rate(self.rateValue)


        self.twist_pub = rospy.Publisher('/mobile_base/commands/velocity', Twist, queue_size=1)
        self.motorPower_pub = rospy.Publisher('/mobile_base/commands/motor_power', MotorPower, queue_size=1)
        
        self.odomReset = rospy.Publisher('/mobile_base/commands/reset_odometry', Empty, queue_size=1)

        # self.imu_sub = rospy.Subscriber("/mobile_base/sensors/imu_data", Imu, self.imuCallback, queue_size=1)
        self.odom_sub = rospy.Subscriber("/odom", Odometry, self.odomCallback, queue_size=1)
        # self.power_system_sub = rospy.Subscriber("/mobile_base/events/power_system", PowerSystemEvent, self.powerSystemCallback, queue_size=1)
        self.bumper_sub = rospy.Subscriber("/mobile_base/events/bumper", BumperEvent, self.bumperCallback, queue_size=1)
        self.lidar_sub = rospy.Subscriber("/scan", LaserScan, self.lidarCallback, queue_size=1)
        self.ultrasonic_left_sub = rospy.Subscriber("/ultrasonic_left", Range, self.ultrasonicLeftCallback, queue_size=1)
        self.ultrasonic_right_sub = rospy.Subscriber("/ultrasonic_right", Range, self.ultrasonicRightCallback, queue_size=1)
        self.qr_code_sub = rospy.Subscriber('/qrCode', String, self.qrCodeCallback, queue_size=1)
        self.bumperIDs = SensorObjekt(frontLeft=0, frontRight=2, frontCenter=1)
        self.bumperStates = [0] * 3
        self.lidarDistance = [0]*360
        self.motorPower = MotorPower()
        self.ultrasonicLeftValue = Range()
        self.ultrasonicRightValue = Range()
        self.qrCode = ""
        self.running = False
        self.currentMoveValue = Twist() #{'x': 0.0, 'y': 0.0, 'ang': 0.0}
        self.currentMoveValue.linear.x = 0.0
        self.currentMoveValue.linear.y = 0.0
        self.currentMoveValue.angular.z = 0.0

        self.maxSpeed = 0.3

        self.__stepThread = None
        self.__TimerCallback = Callable
        self.__currentOdomValue = Odometry()
        self.__lastOdomValue = Odometry()

    def printROSINFO(self, msg):
        timeMsg = "Time: %s" % rospy.get_time()
        rospy.loginfo("{0} --> {1}".format(msg, timeMsg))

    def imuCallback(self, data):
        # pass
        self.printROSINFO(data)

    def odomCallback(self, data):
        # self.printROSINFO(data)
        self.__currentOdomValue = data

    def powerSystemCallback(self, data):
        self.printROSINFO(data)

    def ultrasonicLeftCallback(self, data):
        # self.printROSINFO(data)
        self.ultrasonicLeftValue = data

    def ultrasonicRightCallback(self, data):
        # self.printROSINFO(data)
        self.ultrasonicRightValue = data

    def lidarCallback(self, data):
        # self.printROSINFO(data.ranges[180])
        self.lidarDistance = data.ranges
        sumQu = (data.ranges[270] + data.ranges[271] + data.ranges[269])/3
        # print("*******************************", type(sumQu), sumQu)
    
    def bumperCallback(self, data):
        self.bumperStates[data.bumper] = data.state
        print(self.bumperStates)
        self.printROSINFO(data.bumper)

    def qrCodeCallback(self, data):
        self.qrCode = data.data
        # self.printROSINFO(data)

    def get_rotation (self, msg):
        global roll, pitch, yaw
        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        (roll, pitch, yaw) = euler_from_quaternion (orientation_list)
        # print(yaw*180.0/math.pi)
        return yaw


    def resetOdom(self):
        self.odomReset.publish(Empty())

    def __moveStepsFinisher(self, x:float, y:float, ang:float, callback:callable=None):
        self.moveRobot(x, y, ang)
        currentOdo = self.__currentOdomValue
        self.get_rotation(currentOdo)
        # print("-----------------", euler_from_quaternion([currentOdo.pose.pose.orientation.x, currentOdo.pose.pose.orientation.y, currentOdo.pose.pose.orientation.z]))
        # print("lastOdom:", self.__lastOdomValue.pose, "current:", currentOdo.pose)
        if(callback != None):
            callback("finish")


    def runTurning(self, ang, call):
        self.moveRobot(0.0, 0.0, ang)
        print("startRunningTunning: ", ang, self.get_rotation(self.__currentOdomValue))
        while abs(self.get_rotation(self.__currentOdomValue) - (self.get_rotation(self.__lastOdomValue))) < abs(ang):
            time.sleep(0.00001)
        self.moveRobot(0.0, 0.0, 0.0)
        if call != None:
            call("finish")

    def moveSteps(self, steplength:float, numsteps:int, stepspeedx:float, callback:callable=None):
        maxSpeed = 1.0
        self.__TimerCallback = callback
        timeToMove = (steplength / abs(stepspeedx)) * numsteps
        self.__lastOdomValue = self.__currentOdomValue
        self.odomReset.publish(Empty())
        self.moveRobot(stepspeedx, 0.0, 0.0)
        self.__stepThread = threading.Timer(timeToMove, self.__moveStepsFinisher, [0.0, 0.0, 0.0, callback])
        self.__stepThread.start()

    def moveTurnStep(self, steplength:float, numsteps:int, stepspeedang:float, callback:callable=None):
        maxSpeed = 1.0
        print("moveTURNSTEP:", stepspeedang)
        self.__TimerCallback = callback
        timeToMove = (steplength / abs(stepspeedang)) * numsteps
        self.__lastOdomValue = self.__currentOdomValue
        # self.moveRobot(0.0, 0.0, stepspeedang)
        self.__stepThread = threading.Thread(target=self.runTurning, args=[stepspeedang, callback])
        # self.__stepThread = threading.Timer(timeToMove, self.__moveStepsFinisher, [0.0, 0.0, 0.0, callback])
        self.__stepThread.start()

    def moveTurnStepGrad(self, steplength:float, numsteps:int, stepspeedangGrad:float, callback:callable=None):
        stepspeedangRad = stepspeedangGrad * (math.pi/180.0)

        self.moveTurnStepRad(steplength, numsteps, stepspeedangRad, callback)

    def moveTurnStepRad(self, steplength:float, numsteps:int, stepspeedangRad:float, callback:callable=None):
        self.__TimerCallback = callback
        self.__lastOdomValue = self.__currentOdomValue
        self.__stepThread = threading.Thread(target=self.runTurning, args=[stepspeedangRad, callback])
        self.__stepThread.start()

    def checkRobotLeftRightUnavailable(self):
        rangesLeft = self.filterInf(self.lidarDistance[200:351]) #270⁰ +- 30°#70
        rangesRight = self.filterInf(self.lidarDistance[20:161]) #90° +- 30°
        # print("rangesLeft", rangesLeft, "rangesRight", rangesRight)
        returnValue = CollistionTyp.NOTHING
        if (len(rangesLeft) > 0 and len(rangesRight) > 0):
            lidarLeftAverage = np.min(rangesLeft)
            lidarRightAverage = np.min(rangesRight)
            # print("lidarLeftAverage", lidarLeftAverage, "lidarRightAverage", lidarRightAverage)
            if(lidarLeftAverage < 0.40): #0.18
                returnValue = CollistionTyp.LIDAR_LEFT
            if(lidarRightAverage < 0.40):#0.18
                returnValue = CollistionTyp.LIDAR_RIGHT
            if(lidarRightAverage < 0.40 and lidarLeftAverage < 0.40): #0.18 0.18
                returnValue = CollistionTyp.LIDAR_LEFT_RIGHT
        
        return returnValue


    def checkSpeed(self, currSpeed:float) -> float:
        if (currSpeed > self.maxSpeed):
            currSpeed = self.maxSpeed
        elif (currSpeed < 0 and abs(currSpeed) > self.maxSpeed):
            currSpeed = self.maxSpeed * -1

        return currSpeed

    def moveRobot(self, x:float, y:float, ang:float):
        self.currentMoveValue.linear.x = self.checkSpeed(x)
        self.currentMoveValue.linear.y = self.checkSpeed(y)
        self.currentMoveValue.angular.z = ang
        self.checkCollision()
        # msg = Twist()
        # msg.linear.x = se
        # msg.linear.y = y
        # msg.angular.z = ang
        self.twist_pub.publish(self.currentMoveValue)

    # ###############################################################################################################################################
    # FILTER AN PASSEN ES SIND ZU KLEINE WERTE VLT NICHT MIT 0.0 ALS START WERT
    # DISTANZ MESSUNG IST FLASCH ES SPRINGT HOCH RUNTER 
    # ###############################################################################################################################################
    def filterInf(self, arr):
        returnArr = []# * len(arr)
        # print(len(arr))
        for i in range(len(arr)):
            if(not math.isinf(arr[i])):
                # returnArr[i] = arr[i]
                returnArr.append(arr[i])
        return returnArr

    def checkCollision(self):
        isCollided = False
        returnValue = CollistionTyp.NOTHING
        # rangesFront = self.lidarDistance[150:211]
        # rangesBack = self.lidarDistance[329:] + self.lidarDistance[:31]
        rangesFront = self.filterInf(self.lidarDistance[150:211])
        rangesBack = self.filterInf(self.lidarDistance[329:] + self.lidarDistance[:31])
        # lidarFrontAverage = np.mean(self.filterInf(rangesFront))
        # lidarBackAverage = np.mean(self.filterInf(rangesBack))
        # lidarLeftAverage = np.mean(self.lidarDistance[265:275])
        # lidarRightAverage = np.mean(self.lidarDistance[85:95])
        # print("lidarFrontAverage: ", (np.min(self.filterInf(rangesFront))))
        # print("lidarBackAverage: ", (np.min(self.filterInf(rangesBack))))
        # print("lidarBackAverage: ", lidarBackAverage)
        if (len(rangesFront) > 0 and len(rangesBack) > 0):
            lidarFrontAverage = np.min(rangesFront)
            lidarBackAverage = np.min(rangesBack)
            if(lidarFrontAverage < 0.16):
                if(self.currentMoveValue.linear.x > 0):
                    self.currentMoveValue.linear.x = 0.0
                    returnValue = CollistionTyp.LIDAR_FRONT
                    print("********* COLLISTION FRONT")
                    isCollided = True
                self.twist_pub.publish(self.currentMoveValue)
            elif(lidarBackAverage < 0.50):
                if(self.currentMoveValue.linear.x < 0):
                    self.currentMoveValue.linear.x = 0.0
                    returnValue = CollistionTyp.LIDAR_BACK
                    isCollided = True
                self.twist_pub.publish(self.currentMoveValue)
        
        for bumperIndex in range(len(self.bumperStates)):
            if (self.bumperStates[bumperIndex] == 1):
                returnValue = self.getBumperCollistionID(bumperIndex)
                if(self.currentMoveValue.linear.x > 0):
                    self.currentMoveValue.linear.x = 0.0
                    isCollided = True
                elif(self.currentMoveValue.linear.y > 0):
                    self.currentMoveValue.linear.y = 0.0
                    isCollided = True
                self.twist_pub.publish(self.currentMoveValue)
            
        if(isCollided):
            self.printROSINFO("COLLISION!!")
            if(self.__stepThread != None):
                if(self.__stepThread.is_alive()):
                    # self.__stepThread.cancel()
                    self.__stepThread.join()
                    self.__TimerCallback("ROBOT IS COLLIDED")
        return returnValue

    def getBumperCollistionID(self, index) -> CollistionTyp:
        if (index == self.bumperIDs.FRONT_CENTER):
            return CollistionTyp.BUMPER_CENTER
        elif (index == self.bumperIDs.FRONT_LEFT):
            return CollistionTyp.BUMPER_LEFT
        elif (index == self.bumperIDs.FRONT_RIGHT):
            return CollistionTyp.BUMPER_RIGHT

    def shutdown(self):
        self.running = False
        rospy.signal_shutdown("close the Node")
        self.join()
        print("Robot says: Bye Bye")


    def run(self):
        self.running = True
        # rate = rospy.Rate(10)
        while (not rospy.is_shutdown() and self.running):
            # self.printROSINFO("while Loop")
            self.checkCollision()
            # print(self.checkRobotLeftRightUnavailable())
            self.twist_pub.publish(self.currentMoveValue)
            # self.moveRobot(self.currentMoveValue.linear.x, self.currentMoveValue.linear.y, self.currentMoveValue.angular.z)
            self.rate.sleep()
        print("End of LIBRobot Running")
