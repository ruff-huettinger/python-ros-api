import os, sys
import threading, time
import socket
import queue as QU

__all__ = ["NetworkServer"]
__version__ = "0.0.1"
__author__ = "Firat Goek <f.goek@huettinger.de>"



class NetworkServer(threading.Thread):
    """NetworkServer: 
    This class creates a UDP or TCP socket server.
    The constructor allows the configuration of the protocol.
    This class creates a commination between the listening address and the sending address. 
    It is possible to switch between UDP and TCP communication. 
    The class runs in a thread because it listens in a continuous loop for messages to be received.
   
    Attributes:
        sendingAddress tuple(str, int): The Sending IP and Port Address.
        listeningAddress tuple(str, int): The Listening IP and Port Address.
        protocolType (str): The Protocol Type -> UDP or TCP.
        bufferSize (int): The reading Buffer Size.
        running (bool): The bool for the permanent-loop to read Messages.
        Name (str): The name of the Class instance.
        callbackFunc (functionptr): The Function for calling when a new message comes in.
        DEBUG (bool): The Switch for debug mode.
        socket (socket): The Socket for the communication.
        tcpTupe (tcpSocket): The Socket for TCp communication.
    """    

    def __init__(self, ListenIP:str, ListenPort:int, SendIP:str, SendPort:int=5000, Protocol:str="udp", BufferSize:int=1024, CallbackFunc=None, Name:str="NetworkServer"):
        """Constructor for the NetworkServer

        Args:
            ListenIP (str): IP-Adress for Listening
            ListenPort (int): Port of the Listening
            SendIP (str): IP-Address for Sending
            SendPort (int, optional): Port for Sending. Defaults to 5000.
            Protocol (str, optional): Type of the Network communication Protokol UDP/TCP. Defaults to "udp".
            BufferSize (int, optional): Size of the reading Message. Defaults to 1024.
            CallbackFunc (Function, optional): is called when a new message comes in. Defaults to None.
            Name (str, optional): Name of the Class instance. Defaults to "NetworkServer".
        """

        threading.Thread.__init__(self)
        self.sendingAddress = (SendIP, SendPort)
        self.listeningAddress = (ListenIP, ListenPort)
        self.protocolType = Protocol
        self.bufferSize = BufferSize
        self.running = False
        self.runConnection = True
        self.Name = Name
        self.callbackFunc = CallbackFunc
        self.messageQueue = QU.Queue()
        self.DEBUG = True
        self.socket = socket.socket()
        # self.socket.setblocking(False)
        self.tcpTupe = None

    
    def __initTCP(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setblocking(False)
        self.socket.settimeout(5)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(self.listeningAddress)
        self.socket.listen(1)

    def __initUDP(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(self.listeningAddress)
        # self.socket.setblocking(False)

    def run(self):
        """Method representing the thread's activity.
        This method has been overridden to work on the specific functionality.
        """
        self.running = True
        self.runConnection = True
        self.__debugPrint("Start Listening with <{}> Protocol on Address: {}".format(self.protocolType, self.listeningAddress), self.DEBUG)

        if(self.protocolType.lower() == "udp"):
            self.__initUDP()
            self.__debugPrint("init UDP finish", self.DEBUG)
            self.runUDP()
        else:
            self.__initTCP()
            self.__debugPrint("init TCP finish", self.DEBUG)
            self.runTCP()
        
    
    def runUDP(self):
        """This Method is for the UDP communiction.
        running the UDP connection in the Thread run Methode.
        """
        while self.running:
            failure = False
            try: 
                data, addr = self.socket.recvfrom(self.bufferSize)
            except:
                failure = True
            
            if not failure:
                self.__debugPrint("New {}-Message: {}".format(self.protocolType, data.decode()), True)
                if(self.callbackFunc != None):
                    threading.Thread(target=self.callbackFunc, args=[data.decode()]).start()
                else:
                    self.messageQueue.put(data.decode())
        self.__debugPrint("Stop Listening", True)
    
    def runTCP(self):
        """This Method is for the TCP communiction.
        running the TCP connetction in the Thread run Method
        """
        while self.running:
            try:
                conn, addr = self.socket.accept()
                self.tcpTupe = conn
                self.sendingAddress = addr
            except:
                continue
            self.__debugPrint("Start Listening with <{}> Protocol on Address: {}".format(self.protocolType, self.listeningAddress), self.DEBUG)

            while self.runConnection:
                try:
                    data = self.tcpTupe.recv(self.bufferSize)
                except:
                    data = None
                    self.__debugPrint("Received Invalid Data", True)
                if not data:
                    break
                self.__debugPrint("New {}-Message: {}".format(self.protocolType, data.decode()), True)
                if(self.callbackFunc != None):
                    threading.Thread(target=self.callbackFunc, args=[data.decode()]).start()
                else:
                    self.messageQueue.put(data.decode())
            self.tcpTupe.close()
            self.__debugPrint("Lost Connection", True)
        self.__debugPrint("Stop Listening", True)


    def getMessage(self) -> str:
        """This is a Methode to get the Message from the QUEUE.

        Returns:
            str: Return the Message in the queue (FIFO)
        """
        result = None
        self.__debugPrint("Read the Message Buffer", self.DEBUG)
        if not self.messageQueue.empty():
            result = self.messageQueue.get()
        return result

    def hasMessage(self) -> bool:
        """This is a Methode to check if a message arrived in the queue.

        Returns:
            bool: Return True if the queue has a messages and False if the queue is empty
        """
        return not self.messageQueue.empty()

    
    def sendMessage(self, msg):
        """ This is a Methode to send a Message

        Args:
            msg (str): sending Message
        """
        self.__debugPrint("Sending a Message: {} to Address: {}".format(msg, self.sendingAddress), self.DEBUG)
        if(self.protocolType.lower() == "udp"):
            self.socket.sendto(msg.encode(), self.sendingAddress)
        else:
            try:
                self.tcpTupe.sendto(msg.encode(), self.sendingAddress)
            except:
                self.__debugPrint("Verbindung steht noch nicht kann nicht Nachricht kann nicht gesendet werden")
        
         
    def __debugPrint(self, msg:str, printing:bool=False):
        """This Method is for debug printing

        The method writes the message to the console. 
        The parameter Debug can be used to determine whether 
        the message should be written in Debug mode or if the message should always be printed. 

        Args:
            msg (str): the Message to print to the Terminal
            debug (bool, optional): Switch for the Message. Defaults to False.
        """
        if(printing):
            print("[ {} ] {}".format(self.Name, msg))

    def shutdown(self):
        print("shutdwon Lib Network")
        self.running = False
        self.runConnection = False
        self.join()


# testing 

# def callBack(msg):
#     print("heyyyyyy:" , msg)
#     time.sleep(1)
#     print("end:" , msg)

# udpserver = NetworkServer("172.20.72.12", 5000, "172.20.53.153", 5001, "UDP", CallbackFunc=callBack)
# udpserver.start() 
# time.sleep(2)
# for _ in range(50):
#     udpserver.sendMessage("hallo from Python")
#     time.sleep(1)