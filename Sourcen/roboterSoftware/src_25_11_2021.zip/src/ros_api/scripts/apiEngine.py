import roslib; roslib.load_manifest('ros_api')
from ros_api.lib_robot import Robot
from ros_api.lib_Network import NetworkServer
from ros_api.pledgeAlgorithm import PledgeAlgo

import time, re, sys, math


class APIEngine():
    COMMANDS = [
        'forward',
        'backward', 
        'left',
        'right',
        'turn_left',
        'turn_right',
        'diagonal_forward_left',
        'diagonal_backward_right',
        'diagonal_forward_left',
        'diagonal_backward_right',
        'stop',
        'stopall',
        'station',
        'algorithm', 
        'resetOdom',
        'testMoveToWall',
        'testTurnLeft',
        'testTurnRight',
        'testFollowWall'
    ]
    
    def __init__(self):
        self.__networkSettings = {
            'sendingIP': "192.168.2.116", #"172.20.53.153"
            'sendingPort': 5001,
            'listeningIP': '192.168.2.159', #"192.168.2.165",
            'listeningPort': 5000,
            'protocolType': "UDP",
            'bufferSize': 1024,
            'name': "APIEngineNetworkServer"
        }

        # Instantiate classes
        self.networkServer = NetworkServer(
                            ListenIP=self.__networkSettings['listeningIP'],
                            ListenPort=self.__networkSettings['listeningPort'],
                            SendIP=self.__networkSettings["sendingIP"],
                            SendPort=self.__networkSettings["sendingPort"],
                            Protocol=self.__networkSettings["protocolType"],
                            BufferSize=self.__networkSettings["bufferSize"],
                            Name=self.__networkSettings["name"],
                            CallbackFunc=self.NetworkCallback                            
                        )
        self.robot = Robot()

        self.algorthim = PledgeAlgo(self.robot)


        self.__currentCommandAndSpeed = []
        self.__currentCommandActive = []
        self.__defaultSpeed = 1.0
        self.__steplength = 0.05
        self.__stepSpeed = 1.0
        
        # regex Patter for api Message: x:n.n;y:n.n;ang:n.n;
        self.__regexPatter = "(x:[+-]?[0-9]*[.]?[0-9]+);(y:[+-]?[0-9]*[.]?[0-9]+);(ang:[+-]?[0-9]*[.]?[0-9]+);" 

        # start the Threads
        self.networkServer.start()
        self.robot.start()

    def NetworkCallback(self, msg):
        print("new Message: ", msg)
        msg = msg.replace('\n','')
        if(msg in self.COMMANDS):
            # self.__currentCommandActive = msg.split('_')
            self.__currentCommandActive = msg
        else:
            msgMatch = re.search(self.__regexPatter, msg)

            if(msgMatch):
                print(msgMatch.group())
                coords = list(filter(None, msgMatch.group().split(";")))
                for i in range(len(coords)):
                    self.__currentCommandAndSpeed.append(coords[i].split(":"))


    def StepMoveCallback(self, msg):
        self.networkServer.sendMessage(msg)

    def update(self):
        if(self.__currentCommandAndSpeed):
            print("update: ", self.__currentCommandAndSpeed)
        if (self.__currentCommandActive):
            print("update-Step: ", self.__currentCommandActive)
    
    def output(self):

        if self.__currentCommandAndSpeed:
            deg = float(self.__currentCommandAndSpeed[2][1])*(math.pi/180.0)
            print(deg)
            self.robot.moveRobot(float(self.__currentCommandAndSpeed[0][1]), float(self.__currentCommandAndSpeed[1][1]), float(deg))
            self.__currentCommandAndSpeed = []
        if self.__currentCommandActive and len(self.__currentCommandActive) > 1:
            if self.__currentCommandActive == 'forward':
                self.robot.moveSteps(0.1, 1, 0.05, self.StepMoveCallback)
            elif self.__currentCommandActive == 'backward':
                self.robot.moveSteps(0.1, 1, -0.05, self.StepMoveCallback)
            elif self.__currentCommandActive == 'turn_left':
                # deg = 45.0 * (math.pi / 180.0)
                # self.robot.moveTurnStep(1, 1, deg, self.StepMoveCallback)
                self.robot.moveTurnStepGrad(1, 1, 45.0, self.StepMoveCallback)
            elif self.__currentCommandActive == 'turn_right':
                # deg = -45.0 * (math.pi / 180.0)
                # self.robot.moveTurnStep(1, 1, deg, self.StepMoveCallback)
                self.robot.moveTurnStepGrad(1, 1, -45.0, self.StepMoveCallback)
            elif self.__currentCommandActive == 'algorithm':
                self.algorthim = PledgeAlgo(self.robot)
                self.algorthim.start()
            elif self.__currentCommandActive == 'stop':
                self.algorthim.stop()
            elif self.__currentCommandActive == 'resetOdom':
                self.robot.resetOdom()
            elif self.__currentCommandActive == 'testMoveToWall':
                self.algorthim.moveToNextWall()
            elif self.__currentCommandActive == 'testTurnLeft':
                self.algorthim.turnLeft()
            elif self.__currentCommandActive == 'testTurnRight':
                self.algorthim.turnRight()
            elif self.__currentCommandActive == 'testFollowWall':
                self.algorthim.followWall()                
            self.__currentCommandActive = []
        elif (self.__currentCommandActive):
            print("output: ", self.__currentCommandActive[0])
            if self.__currentCommandActive[0] == 'forward':
                self.robot.moveSteps(0.1, 1, 0.05, self.StepMoveCallback)
            elif self.__currentCommandActive[0] == 'backward':
                self.robot.moveSteps(0.1, 1, -0.05, self.StepMoveCallback)
            elif self.__currentCommandActive[0] == 'turn_left':
                # deg = 45.0 * (math.pi / 180.0)
                # self.robot.moveTurnStep(1, 1, deg, self.StepMoveCallback)
                self.robot.moveTurnStepGrad(1, 1, 45.0, self.StepMoveCallback)
            elif self.__currentCommandActive[0] == 'turn_right':
                # deg = -45.0 * (math.pi / 180.0)
                # self.robot.moveTurnStep(1, 1, deg, self.StepMoveCallback)
                self.robot.moveTurnStepGrad(1, 1, -45.0, self.StepMoveCallback)
            elif self.__currentCommandActive[0] == 'algorithm':
                self.algorthim = PledgeAlgo(self.robot)
                self.algorthim.start()
            elif self.__currentCommandActive == 'stop':
                self.algorthim.stop()
            elif self.__currentCommandActive == 'resetOdom':
                self.robot.resetOdom()
            elif self.__currentCommandActive == 'testMoveToWall':
                self.algorthim.moveToNextWall()
            elif self.__currentCommandActive == 'testTurnLeft':
                self.algorthim.turnLeft()
            elif self.__currentCommandActive == 'testTurnRight':
                self.algorthim.turnRight()
            elif self.__currentCommandActive == 'testFollowWall':
                self.algorthim.followWall()

            self.__currentCommandActive = []

    def shutdown(self):
        self.robot.shutdown()
        self.networkServer.shutdown()



def main():
    goodbyeEmojisRobot = ['\U0001f916'] * 1
    goodbyeEmojisHands = ['\U0001f44b'] * 5
    api = APIEngine()
    # robot = Robot()
    # robot.start()

    while True:
        # if(networkServer.hasMessage()):
        #     print(networkServer.getMessage())
        try:
            i = 1 + 1
            api.update()
            api.output()
            time.sleep(0.001)
        except KeyboardInterrupt:
            print("Goodbye from ROS API {0} {1}".format(' '.join(map(str, goodbyeEmojisRobot)), ' '.join(map(str, goodbyeEmojisHands))))
            sys.exit(0)
            api.shutdown()

if __name__ == '__main__':
    main()