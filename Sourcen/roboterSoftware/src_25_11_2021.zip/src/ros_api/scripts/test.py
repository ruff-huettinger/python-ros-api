 #!/usr/bin/env python3

import rospy


def tester():
	print("Start testing")
	rospy.init_node('tester')
	rate = rospy.Rate(25) # 25Hz
	while not rospy.is_shutdown():
		curTime = "Time: %s" % rospy.get_time()
		rospy.loginfo(curTime)
		rate.sleep()
		


if __name__ == '__main__':
	try:
		tester()
	except rospy.ROSInterruptException:
		print("Error")
		
