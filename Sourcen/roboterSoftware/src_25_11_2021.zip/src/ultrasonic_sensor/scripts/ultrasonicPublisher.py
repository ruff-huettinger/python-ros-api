 #!/usr/bin/env python3
from os import name
import RPi.GPIO as GPIO
import time

from ultrasonic_sensor.ultrasonic import UltrasonicSensor

import rospy
from sensor_msgs.msg import Range



if __name__ == '__main__':
    publisherUltrasonicLeft = rospy.Publisher('ultrasonic_left', Range, queue_size=1)
    publisherUltrasonicRight = rospy.Publisher('ultrasonic_right', Range, queue_size=1)
    rospy.init_node('ultrasonic_Sensor')
    rate = rospy.Rate(50) # 25Hz
    ultrasonicRight = UltrasonicSensor(triggerPin=6, echoPin=13, name="leftSensor")
    ultrasonicLeft = UltrasonicSensor(triggerPin=19, echoPin=26, name="rightSensor")

    try:
        ultrasonicLeft.start()
        ultrasonicRight.start()

        while not rospy.is_shutdown():
            distanceLeft = Range()
            distanceLeft.header.stamp = rospy.Time.now()
            distanceLeft.range = ultrasonicLeft.getDistance()
            
            distanceRight = Range()
            distanceRight.header.stamp = rospy.Time.now()
            distanceRight.range = ultrasonicRight.getDistance()

            publisherUltrasonicLeft.publish(distanceLeft)
            publisherUltrasonicRight.publish(distanceRight)
            rate.sleep()
    except rospy.ROSInterruptException:
        print("Error")