 #!/usr/bin/env python3
import RPi.GPIO as GPIO
import time

import rospy
from sensor_msgs.msg import Range


US_SENSOR_TRIGGER = 23
US_SENSOR_ECHO = 24

Messung_Max = 0.1             # in sekunden
Messung_Trigger = 0.00001     # in sekunden
Messung_Pause = 0.2           # in sekunden
Messung_Faktor = (343.460 / 2.0) # Schallgeschwindigkeit durch 2 (hin und zurück) in mm/s
        # Schallgeschwindigkeit gem. https://de.wikipedia.org/wiki/Schallgeschwindigkeit
        # +20°C 343,46m/s
        #   0°C 331,50m/s
        # −20°C 319,09m/s
Abstand_Max = 4000            # Max value in mm
Abstand_Max_Error = Abstand_Max + 1
Distanz = -1
StartZeit = 0
StopZeit = 0

def US_SENSOR_EchoInterrupt(US_SENSOR_ECHO):
    global StartZeit, StopZeit, Distanz
    Distanz = -1
    
    # Speichere Zeit
    Zeit = time.time()
    if GPIO.input(US_SENSOR_ECHO) == 1:
        # steigende Flanke
        StartZeit = Zeit
    else:
        # fallende Flanke
        StopZeit = Zeit
        # Zeit = StopZeit - StartZeit
        # Distanz = Zeit * Messung_Faktor

    if StartZeit < StopZeit:
        # berechne Zeitdifferenz zwischen Start und Ankunft im Sekunden
        Zeit = StopZeit - StartZeit
        # berechne Distanz
        Distanz = Zeit * Messung_Faktor
    else:
        # setze Fehlerwert
        Distanz = Abstand_Max_Error



if __name__ == '__main__':
    pub = rospy.Publisher('ultrasonic_left', Range, queue_size=1)
    rospy.init_node('ultrasonic_Sensor')
    rate = rospy.Rate(25) # 25Hz
    GPIO.setmode(GPIO.BCM)                    # GPIO Modus (BOARD / BCM)
    GPIO.setup(US_SENSOR_TRIGGER, GPIO.OUT)   # Trigger-Pin = Raspberry Pi Output
    GPIO.setup(US_SENSOR_ECHO, GPIO.IN)       # Echo-Pin = raspberry Pi Input

    GPIO.add_event_detect(US_SENSOR_ECHO, GPIO.BOTH, callback = US_SENSOR_EchoInterrupt)
    
    try:
        while not rospy.is_shutdown():
            GPIO.output(US_SENSOR_TRIGGER, True)
            time.sleep(Messung_Trigger)
            GPIO.output(US_SENSOR_TRIGGER, False)
            
            dis = Range()
            dis.header.stamp = rospy.Time.now()
            dis.range = Distanz

            pub.publish(dis)
            if Distanz >= Abstand_Max:
                # Ausgabe Text
                print ("Kein Objekt gefunden")
            else:
                # Ausgabe Text
                print ("Gemessene Entfernung = %f m" % Distanz)
            rate.sleep()
    except rospy.ROSInterruptException:
        print("Error")
        GPIO.cleanup()