import RPi.GPIO as GPIO
import threading, time


class UltrasonicSensor(threading.Thread):
    def __init__(self, triggerPin, echoPin, name="ultrasonic"):
        super().__init__()
        self.NAME = name
        self.TRIGGER_PIN = triggerPin
        self.ECHO__PIN = echoPin
        self.TIME_TRIGGER = 0.00001
        self.TIME_PAUSE = 0.5#0.2
        self.TIME_TIMEOUT = 1
        self.ECHO_FAKTOR = (343.460 / 2.0)
        self.RANGE_MAX = 4.000 # max value in mm
        self.RANGE_MAX_ERROR = self.RANGE_MAX + 1

        self.running = False
        self.distance = self.RANGE_MAX_ERROR
        self.distanceValues = []
        self.averageCounter = 0

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.TRIGGER_PIN, GPIO.OUT)
        GPIO.setup(self.ECHO__PIN, GPIO.IN)


    def triggerSensor(self):
        GPIO.output(self.TRIGGER_PIN, True)
        time.sleep(self.TIME_TRIGGER)
        GPIO.output(self.TRIGGER_PIN, False)

    def measureEcho(self):
        self.triggerSensor()
        startTime = time.time()

        nextTimeout = startTime + self.TIME_TIMEOUT

        while startTime < nextTimeout and GPIO.input(self.ECHO__PIN) == 0:
            startTime = time.time()

        stopTime = startTime

        while stopTime < nextTimeout and GPIO.input(self.ECHO__PIN) == 1:
            stopTime = time.time()


        if stopTime < nextTimeout:
            # berechne Zeitdifferenz zwischen Start und Ankunft im Sekunden
            elapsedTime = stopTime - startTime
            # berechne Distanz
            distance = elapsedTime * self.ECHO_FAKTOR
        else:
            # setze Fehlerwert
            distance = self.RANGE_MAX_ERROR

        return distance

    def stop(self):
        self.running
        self.join()
        GPIO.cleanup()

    def getDistance(self):
        return self.distance


    def run(self):
        self.running = True

        while self.running:
            self.distanceValues = []
            for i in range(25):
                self.distanceValues.append(self.measureEcho())
                time.sleep(0.05)
            self.distance = sum(self.distanceValues)/len(self.distanceValues)
            # self.triggerSensor()
            # if(self.averageCounter < 10):
            # 	self.averageCounter += 1
            # 	self.distanceValues.append(self.measureEcho()) 
            # if self.averageCounter >= 10:
            # 	self.averageCounter = 0
            # 	self.distance = sum(self.distanceValues)/len(self.distanceValues)
            # 	self.distanceValues = []
            
            # self.distance = self.measureEcho()
            # print(self.NAME, self.distance)
            time.sleep(self.TIME_PAUSE)



# if __name__ == "__main__":
#     usSensor = UltrasonicSensor(triggerPin=6, echoPin=13, name="leftSensor")
#     usSensor2 = UltrasonicSensor(triggerPin=19, echoPin=26, name="rightSensor")
#     try:
#         usSensor.start()
#         usSensor2.start()
#     except KeyboardInterrupt:
#         usSensor.stop()
#         usSensor2.stop
#         print("Stop")
