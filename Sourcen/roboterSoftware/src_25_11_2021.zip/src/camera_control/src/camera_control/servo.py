import RPi.GPIO as GPIO
import time



class Servo():
    def __init__(self, pwmPin) -> None:
        self.PIN_PWM = pwmPin
        self.currentPWM = 0
        self.currentPostion = 0

        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.PIN_PWM, GPIO.OUT)
        self.servoPwm = GPIO.PWM(self.PIN_PWM, 50) # 50Hz
        self.servoPwm.start(2.5)

    def setServoPosition(self, ang):
        if ang < 0:
            ang = 0
        if ang > 180:
            ang = 180
        self.currentPostion = ang
        self.currentPWM = ang/18 + 2.5
        self.servoPwm.ChangeDutyCycle(self.currentPWM)
        time.sleep(0.5)
        self.servoPwm.ChangeDutyCycle(0)
    
    def getServoPosition(self):
        return self.currentPostion

    def stop(self):
        self.servoPwm.ChangeDutyCycle(0)
        self.servoPwm.stop()
        GPIO.cleanup()   