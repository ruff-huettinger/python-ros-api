from camera_control.servo import Servo

import rospy
from std_msgs.msg import UInt8

servo = Servo(pwmPin=5)
servo.setServoPosition(0)

def mapValue(x, in_min, in_max, out_min, out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)


def servoCallback(msg):
    global servo
    # print(msg)
    ang = mapValue(msg.data, 0, 255, 0, 180)
    # print("test", ang)
    servo.setServoPosition(ang)

if __name__ == '__main__':
    rospy.init_node('camera_servo_node')
    rospy.Subscriber("servoPos", UInt8, servoCallback)
    rospy.spin()