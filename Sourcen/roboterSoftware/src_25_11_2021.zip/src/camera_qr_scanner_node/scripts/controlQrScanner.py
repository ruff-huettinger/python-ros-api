import rospy
from camera_qr_scanner_node.qrCodeScanner import QRScanner
from std_msgs.msg import String
from sensor_msgs.msg import Image

_qrCodeMsg = ""
_qrCodeLastMsg = ""

_pubQrCode = rospy.Publisher("qrCode", String, queue_size=1)
_pubCameraFrame = rospy.Publisher("camera_frame", Image, queue_size=1)

def qrScannerCallback(qrMsg):
    global _pubQrCode, _qrCodeLastMsg, _qrCodeMsg
    print("callback: ", qrMsg)
    _qrCodeLastMsg = _qrCodeMsg
    _qrCodeMsg = qrMsg
    if(_qrCodeMsg != _qrCodeLastMsg):
        _pubQrCode.publish(_qrCodeMsg)

def frameCallback(frame):
    # print(frame)
    pass


if __name__ == '__main__':
    rospy.init_node('camera_qr_scanner_node')
    qrScanner = QRScanner(port=0, qrCallback=qrScannerCallback, frameCallback=frameCallback, debug=False)
    try:
        qrScanner.start()
        rospy.spin()
    except rospy.ROSInterruptException:
        qrScanner.stop()