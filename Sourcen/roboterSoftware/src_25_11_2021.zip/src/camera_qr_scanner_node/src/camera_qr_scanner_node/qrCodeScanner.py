import cv2
import threading, time
import pyzbar.pyzbar as pyzbar


class QRScanner(threading.Thread):
    def __init__(self, port="", qrCallback=None, frameCallback=None, debug=False):
        super().__init__()
        self.DEBUG = debug
        self.running = False
        self.cap = cv2.VideoCapture(port)
        self.set_480p()
        self.qrData = ""
        self.fps = 60
        self.frameRate = 1.0/self.fps
        self.qrCallback = qrCallback
        self.frameCallback = frameCallback
    
    def set_720p(self):
        self.cap.set(3, 1280)
        self.cap.set(4, 720)

    def set_480p(self):
        self.cap.set(3, 640)
        self.cap.set(4, 480)


    def run(self) -> None:
        self.running = True
        while self.running:
            startTime = time.time()
            ret, frame = self.cap.read()

            frameGrey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            data = pyzbar.decode(frameGrey)
            self.qrData = ""
            for obj in data:
                if(self.DEBUG):
                    print(obj.data.decode())
                if(self.qrCallback != None):
                    self.qrCallback(obj.data.decode())
                self.qrData = obj.data.decode()
                for i in range(len(obj.polygon)):
                    cv2.line(frame, obj.polygon[i], obj.polygon[(i + 1)%4], color=(255, 0, 0), thickness=3)


            if (ret):
                frame = cv2.flip(frame, 1)
                if(self.frameCallback != None):
                    self.frameCallback(frame)
                if(self.DEBUG):
                    cv2.imshow("live", frame)

            if cv2.waitKey(1) == ord("q"):
                break
            diff = time.time() - startTime
            if diff < self.frameRate:
                time.sleep(diff)

    def stop(self):
        self.running = False
        self.join()


# def main():
#     qrScanner = QRScanner(0, True)
#     qrScanner.start()


# if __name__ == "__main__":
#     main()