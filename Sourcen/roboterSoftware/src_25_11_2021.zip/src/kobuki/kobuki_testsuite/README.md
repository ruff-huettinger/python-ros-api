kobuki_testsuite
======

This package is mainly used by the tools in kobuki_qtestsuite from the [kobuki_desktop repository](https://github.com/yujinrobot/kobuki_desktop).
